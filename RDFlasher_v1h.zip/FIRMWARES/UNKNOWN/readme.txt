If the flasher fails to identify the device, 
it will look for firmware files in this directory.
